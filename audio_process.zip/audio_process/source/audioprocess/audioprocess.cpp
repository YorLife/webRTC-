// audioprocess.cpp : �������̨Ӧ�ó������ڵ㡣
//
/*
#include "stdafx.h"
#include <stdio.h>
#include "webrtc_vad.h"
#define  FRAMELENGTH 80
#define SAMPLE_RATE 8000
void vadTest(){
	FILE *fpInputf, *fpOutput;
	fpInputf = fopen("F01S00_8k.raw", "rb");
	if (fpInputf == NULL){
		return;
	}
	fpOutput = fopen("F01S00_8k2.raw", "wb");
	VadInst*inst = WebRtcVad_Create();
	WebRtcVad_Init(inst);
	WebRtcVad_set_mode(inst, 2);

	short audioFrame[FRAMELENGTH];
	short audioFrame2[FRAMELENGTH];
	while (!feof(fpInputf))
	{
		int read_size = fread(audioFrame, sizeof(short), FRAMELENGTH, fpInputf);		
		int status = WebRtcVad_Process(inst, SAMPLE_RATE, audioFrame, FRAMELENGTH);
		if (status == -1)
		{
			printf("WebRtcVad_Process is error\n");
			return;
		}
		printf("%d", status);
		if (status == 1){
		fwrite(audioFrame, sizeof(short), read_size, fpOutput);
			fflush(fpOutput);
		}
	}
	fclose(fpOutput);
	fclose(fpInputf);
	WebRtcVad_Free(inst);

}

int _tmain(int argc, _TCHAR* argv[])
{
	vadTest();
	return 0;
}
*/
// audioprocess.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include<stdlib.h>
#include<stdio.h>
#include"webrtc_vad.h"

#include<stdio.h>
#include<iostream>
#include<vector>
#include<Windows.h>
#include<fstream>  
#include<iterator>
#include<io.h>
//#include<io>

#include<string>
#include<vector>

#define  FRAMELENGTH 80
#define SAMPLE_RATE 8000

#define MAX_PATH 1024  //�·������
using namespace std;




void vadTest(string input_path, string output_path) {



	FILE *fpInputf, *fpOutput;
	//fpInputf = fopen("D:/code/VAD/audio_process/source/audioprocess/1.wav", "rb");

	const char* in_path = input_path.c_str();
	const char* out_path = output_path.c_str();
	fpInputf = fopen(in_path, "rb");
	//printf("�ҵ��ļ���");
	//system("pause");
	if (fpInputf == NULL) {
		printf("�޷��ҵ��ļ���");
		system("pause");
		return;
	}
	else { printf("�ҵ��ļ���"); }
	//system("pause");
	fpOutput = fopen(out_path, "wb");
	if (fpOutput == NULL) {
		printf("�޷��ҵ��ļ�%s��", out_path);
		//system("pause");
		return;
	}
	else { printf("�ҵ��ļ�%s��", out_path); }
	//system("pause");
	VadInst*inst = WebRtcVad_Create();
	WebRtcVad_Init(inst);
	//MODE ��Ҫ����������
	WebRtcVad_set_mode(inst, 1);

	short audioFrame[FRAMELENGTH];
	short audioFrame2[FRAMELENGTH];

	printf("37��");

	while (!feof(fpInputf))
	{
		int read_size = fread(audioFrame, sizeof(short), FRAMELENGTH, fpInputf);
		int status = WebRtcVad_Process(inst, SAMPLE_RATE, audioFrame, FRAMELENGTH);
		if (status == -1)
		{
			printf("WebRtcVad_Process is error\n");
			printf("46��");

			return;
		}
		printf("%d", status);

		if (status == 1) {
			fwrite(audioFrame, sizeof(short), read_size, fpOutput);
			fflush(fpOutput);
		}
	}

	printf("54��");
	//system("pause");
	fclose(fpOutput);
	fclose(fpInputf);
	WebRtcVad_Free(inst);

}



/*
 void getFiles(const std::string & path, std::vector<std::string> & files)
 {
 //�ļ����
 long hFile = 0;
 //�ļ���Ϣ��_finddata_t��Ҫio.hͷ�ļ�
 struct _finddata64i32_t fileinfo;
 std::string p;
 if ((hFile = _findfirst64i32(p.assign(path).append("\\*").c_str(), &fileinfo)) != -1)
 {
 do
 {
 //�����Ŀ¼,����֮
 //�������,�����б�
 if (fileinfo.attrib )
 {
 if (strcmp(fileinfo.name, ".") != 0 && strcmp(fileinfo.name, "..") != 0)
 getFiles(p.assign(path).append("\\").append(fileinfo.name), files);
 }
 else
 {
 files.push_back(p.assign(path).append("\\").append(fileinfo.name));
 }
 } while (_findnext64i32(hFile, &fileinfo) == 0);
 _findclose(hFile);
 }
 }
 */
void getFiles(string path, vector<string>& files, vector<string>& files_alone)
{
	//�ļ����
	intptr_t hFile = 0;
	//�ļ���Ϣ
	struct _finddata_t fileinfo;
	string p;
	if ((hFile = _findfirst(p.assign(path).append("\\*").c_str(), &fileinfo)) != -1)
	{
		do
		{
			//�����Ŀ¼,����֮
			//�������,�����б�
			if ((fileinfo.attrib &  _A_SUBDIR))
			{
				if (strcmp(fileinfo.name, ".") != 0 && strcmp(fileinfo.name, "..") != 0)
					getFiles(p.assign(path).append("\\").append(fileinfo.name), files, files_alone);
			}
			else
			{
				files_alone.push_back(fileinfo.name);
				files.push_back(p.assign(path).append("\\").append(fileinfo.name));
			}
		} while (_findnext(hFile, &fileinfo) == 0);
		_findclose(hFile);
	}
}
void _tmain(int argc, _TCHAR* argv[])
{


	//string filePath = "F:\\OVF\\final-voiceprint-training\\voiceprint-training\\data";
	string filePath;
	string OutPath;
	cout << "������Դ�ļ�·��" << endl;
	cin >> filePath;
	cout << "����������ļ�·��" << endl;
	cin >> OutPath;
	vector<string> files;
	vector<string> files_alone;
	//���Ŀ¼
	//string outpath = "F:\\OVF\\out-testlist";
	////��ȡ��·���µ������ļ�
	getFiles(filePath, files, files_alone);

	char str[30];
	int size = files.size();
	for (int i = 0; i < size; i++)
	{
		cout << files[i].c_str() << endl;
		cout << files_alone[i].c_str() << endl;
		//string out_path = outpath.append("\\").append(files_alone[i].c_str());
		string outpath = OutPath;
		vadTest(files[i].c_str(), outpath.append("\\").append(files_alone[i].c_str()));
	}
	system("pause");


}




